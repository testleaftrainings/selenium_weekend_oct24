package base;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import io.cucumber.testng.AbstractTestNGCucumberTests;

public class ProjectSpecificMethod extends AbstractTestNGCucumberTests{

//	public static ChromeDriver driver;
	private static final ThreadLocal<RemoteWebDriver> rd = new ThreadLocal<RemoteWebDriver>();
	
	public void setDriver(RemoteWebDriver driver) {
		rd.set(driver);
	}
	
	public RemoteWebDriver getDriver() {
		return rd.get();
	}
	
	@BeforeMethod
	public void preCondition() {
//		driver = new ChromeDriver();
		setDriver(new ChromeDriver());
		getDriver().get("http://leaftaps.com/opentaps/");
		getDriver().manage().window().maximize();
	}
	
	@AfterMethod
	public void postCondition() {
		getDriver().quit();
	}
	
	
}
