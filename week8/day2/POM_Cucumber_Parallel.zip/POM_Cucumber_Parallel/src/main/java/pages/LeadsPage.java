package pages;

import org.openqa.selenium.By;

import base.ProjectSpecificMethod;
import io.cucumber.java.en.When;

public class LeadsPage extends ProjectSpecificMethod{

	
	@When("Click on the Create lead link")
	public CreateLeadPage clickCreateLeadLink() {
		getDriver().findElement(By.linkText("Create Lead")).click();
		return new CreateLeadPage();
	}
	
	public void clickFindLeadLink() {
		
	}
	
	public void clickMergeLeadLink() {
		
	}
	
	
}
