package pages;

import org.openqa.selenium.By;

import base.ProjectSpecificMethod;
import io.cucumber.java.en.When;

public class HomePage extends ProjectSpecificMethod{

	
	@When("Click on the Leads tab")
	public LeadsPage clickLeadsTab() {
		getDriver().findElement(By.linkText("Leads")).click();
		return new LeadsPage();
	}
	
	public void clickContactsTab() {
		
	}
	
	public void clickAcountsTab() {
		
	}
	
}
