package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethod;
import io.cucumber.java.en.When;

public class WelcomePage extends ProjectSpecificMethod {

	
	

	@When("Click on the crmsfa link")
	public HomePage clickCrmsfaLink() {
		getDriver().findElement(By.linkText("CRM/SFA")).click();
		return new HomePage();
	}
	
	public LoginPage clickLogoutButton() {
		System.out.println("Logged out successfully");
		return new LoginPage();
	}
	
}
