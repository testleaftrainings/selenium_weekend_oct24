package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethod;

public class CreateLeadPage extends ProjectSpecificMethod{
	
	

	public CreateLeadPage enterCompanyName() {
		getDriver().findElement(By.id("createLeadForm_companyName")).sendKeys("TestLeaf");
		return this;
	}
	
	
	public CreateLeadPage enterFirstName() {
		getDriver().findElement(By.id("createLeadForm_firstName")).sendKeys("Gokul");
		return this;
	}
	
	public CreateLeadPage enterLastName() {
		getDriver().findElement(By.id("createLeadForm_lastName")).sendKeys("Sekar");
		return this;
	}
	
	public CreateLeadPage enterPhoneNumber() {
		getDriver().findElement(By.id("createLeadForm_primaryPhoneNumber")).sendKeys("99");
		return this;
	}
	
	public ViewLeadPage clickCreateLeadButton() {
		getDriver().findElement(By.className("smallSubmit")).click();
		return new ViewLeadPage();
	}

}
