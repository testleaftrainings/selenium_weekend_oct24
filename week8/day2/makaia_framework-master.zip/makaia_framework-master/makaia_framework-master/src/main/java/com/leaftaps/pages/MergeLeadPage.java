package com.leaftaps.pages;

import com.framework.testng.api.base.ProjectSpecificMethods;

public class MergeLeadPage extends ProjectSpecificMethods {

}
