package com.salesforce.pages;

import org.openqa.selenium.WebElement;

import com.framework.selenium.api.design.Locators;
import com.framework.testng.api.base.ProjectSpecificMethods;

public class LoginPage extends ProjectSpecificMethods{

	public LoginPage enterUsername() {
		//find the webElement --> by using locateElement()
		WebElement username = locateElement("username");
		clearAndType(username, "gokul.sekar@testleaf.com");
		reportStep("Username entered successful", "pass");
		return this;
	}
	
	public LoginPage enterPassword() {
		type(locateElement(Locators.ID, "password"), "Leaf@123");
		reportStep("password entered successful", "pass");
		return this;
	}
	
	
	public HomePage ClickLogin() {
//		click(locateElement("Login"));
		click(Locators.ID, "Login");
		reportStep("Login button clicked successful", "pass");
		return new HomePage();
	}
	
	
}
