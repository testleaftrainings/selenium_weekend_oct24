package runner;

import org.testng.annotations.BeforeTest;

import base.ProjectSpecificMethod;
import io.cucumber.java.Scenario;
import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(features = {"src/main/resources/features/"}, glue = {"pages"})
public class CucumberRunner extends ProjectSpecificMethod{

	@BeforeTest
	public void setValues(Scenario scenario) {
		testcaseName = "TC_001_Login";
		testcaseDesc = "Login functionality";
		authorName = "Gokul";
		categoryName = "Regression";
	}
	
}
