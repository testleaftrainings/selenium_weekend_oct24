package testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class TC_001_Login extends ProjectSpecificMethod{

	
	@Test
	public void runLogin() throws IOException {
		LoginPage lp  = new LoginPage();
		/*
		 * lp.enterUsername(); lp.enterPassword(); lp.clickLoginButton();
		 */
		lp.enterUsername()
		.enterPassword()
		.clickLoginButton()
		.clickLogoutButton();
	}
	
	@BeforeTest
	public void setValues() {
		testcaseName = "TC_001_Login";
		testcaseDesc = "Login functionality";
		authorName = "Gokul";
		categoryName = "Regression";
	}
	
}
