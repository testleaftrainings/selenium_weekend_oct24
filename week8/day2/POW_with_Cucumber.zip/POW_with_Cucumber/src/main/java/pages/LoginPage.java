package pages;

import java.io.IOException;

import org.openqa.selenium.By;

import base.ProjectSpecificMethod;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

public class LoginPage extends ProjectSpecificMethod {

	@Given ("Enter the username")
	public LoginPage enterUsername() throws IOException {
		try {
			driver.findElement(By.id("username")).sendKeys("demosalesmanager");
			/*
			 * int randomNumber = (int)(Math.random()*99999); File src =
			 * driver.getScreenshotAs(OutputType.FILE); File desc = new
			 * File("./snaps/img"+randomNumber+".png"); FileUtils.copyFile(src, desc);
			 * test.pass("username entered successfully as demosalesmanager",
			 * MediaEntityBuilder.createScreenCaptureFromPath(".././snaps/img"+randomNumber+
			 * ".png").build());
			 */
			reportStep("pass", "username entered successfully");
		} catch (Exception e) {
			/*
			 * int randomNumber = (int)(Math.random()*99999); File src =
			 * driver.getScreenshotAs(OutputType.FILE); File desc = new
			 * File("./snaps/img1.png"); FileUtils.copyFile(src, desc);
			 * test.fail("unable to enter username",
			 * MediaEntityBuilder.createScreenCaptureFromPath(".././snaps/img1.png").build()
			 * );
			 */
			
			reportStep("fail", "unable to enter username "+e);
		}
		
//		LoginPage lp = new LoginPage();
//		return lp;
//		return new  LoginPage();
		return this;
	}
	
	@Given("Enter the password")
	public LoginPage enterPassword() throws IOException {
		try {
			driver.findElement(By.id("password")).sendKeys("crmsfa");
			reportStep("pass", "password entered successfully");
		} catch (Exception e) {
			reportStep("fail", "unable to enter the password "+e);
		}
		return this;
	}
	
	@When("Click on the login button")
	public WelcomePage clickLoginButton() throws IOException {
		try {
			driver.findElement(By.className("decorativeSubmit")).click();
			reportStep("pass", "Login button clicked successfully");
		} catch (Exception e) {
			reportStep("fail", "unable to click on the login button "+e);
		}
		return new WelcomePage();
	}
	
}
