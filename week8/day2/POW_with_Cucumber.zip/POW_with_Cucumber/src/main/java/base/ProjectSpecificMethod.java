package base;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import io.cucumber.testng.AbstractTestNGCucumberTests;

public class ProjectSpecificMethod extends AbstractTestNGCucumberTests{

	public static ChromeDriver driver;// static - single memory / class level variable
	public String testcaseName, testcaseDesc, authorName, categoryName;
	public ExtentReports extent;
	public static ExtentTest test;
	@BeforeMethod
	public void preCondition() {
		driver = new ChromeDriver();
		driver.get("http://leaftaps.com/opentaps/");
		driver.manage().window().maximize();
		test.info("Browser launched successsfully");
	}
	
	@AfterMethod
	public void postCondition() {
		driver.quit();
	}
	
	
	//Report
	
	@BeforeSuite
	public void startReport() {
	//   1. Set the path for the report
			ExtentHtmlReporter reporter = new ExtentHtmlReporter("./report/result.html");
			reporter.setAppendExisting(true);// to maintain report history
	//   2. Start the report 
			extent = new ExtentReports();
	//   3. Attach the report path file into the report.
			extent.attachReporter(reporter);
	
	}
	
	@BeforeClass
	public void startTestCase() throws IOException {
	//   4. Start testcase for report
			test = extent.createTest(testcaseName, testcaseDesc);
	//   5. Assign the information like author, category
			test.assignAuthor(authorName);
			test.assignCategory(categoryName);

		
				
	}
	
	@AfterSuite
	public void endReport() {
//   7. close the report
		extent.flush();
		System.out.println("Completed");
	}
	
	
	public void reportStep(String status, String desc) throws IOException {
		int randomNumber = (int)(Math.random()*99999);
		File src = driver.getScreenshotAs(OutputType.FILE);
		File des = new File("./snaps/img"+randomNumber+".png");
		FileUtils.copyFile(src, des);
		if(status.equalsIgnoreCase("pass")) {
			test.pass(desc, MediaEntityBuilder.createScreenCaptureFromPath(".././snaps/img"+randomNumber+".png").build());
		}else if (status.equalsIgnoreCase("fail")) {
			test.fail(desc, MediaEntityBuilder.createScreenCaptureFromPath(".././snaps/img"+randomNumber+".png").build());
		}
		
		
	}
	
	
}
