package pages;

public class LeadsPage {

	public CreateLeadPage clickCreateLeadLink() {
		
		return new CreateLeadPage();
	}
	
	public void clickFindLeadLink() {
		
	}
	
	public void clickMergeLeadLink() {
		
	}
	
	
}
