package pages;

public class HomePage {

	public LeadsPage clickLeadsTab() {
		
		return new LeadsPage();
	}
	
	public void clickContactsTab() {
		
	}
	
	public void clickAcountsTab() {
		
	}
	
}
