package pages;

import org.openqa.selenium.By;

import base.ProjectSpecificMethod;

public class LeadsPage extends ProjectSpecificMethod{

	public CreateLeadPage clickCreateLeadLink() {
		driver.findElement(By.linkText(prop.getProperty("createLeadLink"))).click();
		return new CreateLeadPage();
	}
	
	public void clickFindLeadLink() {
		
	}
	
	public void clickMergeLeadLink() {
		
	}
	
	
}
