package base;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

public class ProjectSpecificMethod {

	public static ChromeDriver driver;// static - single memory / class level variable
	public static Properties prop;
	
	@BeforeMethod
	public void preCondition() throws IOException {
//		1. Set the file path into FileInputStream constructor
		FileInputStream fis = new FileInputStream("./src/main/resources/french.properties");
//	    2. Create object reference for properties class
		prop = new Properties();
//	    3. load the FileInputStream into the properties by load()
		prop.load(fis);
		driver = new ChromeDriver();
		driver.get("http://leaftaps.com/opentaps/");
		driver.manage().window().maximize();
	}
	
	@AfterMethod
	public void postCondition() {
		driver.quit();
	}
	
	
}
